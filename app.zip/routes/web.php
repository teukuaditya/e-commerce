<?php

use App\Http\Controllers\User\CategoryController as UserCategoryController;
use App\Http\Controllers\User\HomeController as UserHomeController;
use App\Http\Controllers\User\ProductController as UserProductController;
use App\Http\Controllers\User\CartController as UserCartController;
use App\Http\Controllers\User\CheckoutController as UserCheckoutController;
use App\Http\Controllers\User\OrderController as UserOrderController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\User\UserController;
use App\Http\Controllers\CheckoutController;
use App\Http\Controllers\Auth\LoginController;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\CartController;
use App\Http\Controllers\TransactionController;
use App\Http\Controllers\TransactionDetailController;
use App\Http\Controllers\Api\MidtransController;

Route::get('/', [UserHomeController::class, 'index'])->name('user.home');

Route::post('/logout', [LoginController::class, 'logout'])->name('logout');

Route::prefix('admin')->name('admin.')->group(function () {
    Route::resource('categories', CategoryController::class);
    Route::resource('products', ProductController::class);
    Route::resource('transactions', TransactionController::class);
    Route::resource('transactions-details', TransactionDetailController::class);
    Route::resource('carts', CartController::class);
});

Route::prefix('user')->name('user.')->group(function () {
    // Menampilkan semua produk
    Route::get('/products', [UserProductController::class, 'index'])->name('products.index');

    // Menampilkan detail produk
    Route::get('/products/{id}', [UserProductController::class, 'show'])->name('products.show');

    // Menampilkan kategori produk
    Route::get('/categories', [UserCategoryController::class, 'index'])->name('categories.index');
    Route::get('/categories/{id}', [UserCategoryController::class, 'show'])->name('categories.products');

    // Menampilkan keranjang belanja
    Route::get('/cart', [UserCartController::class, 'index'])->name('cart.index')->middleware('auth');

    // Menambahkan produk ke keranjang (dilindungi middleware auth)
    Route::post('/cart/add/{productId}', [UserCartController::class, 'add'])->name('cart.add')->middleware('auth');

    // Mengupdate jumlah produk dalam keranjang
    Route::put('/cart/{cartId}', [UserCartController::class, 'updateCart'])->name('cart.update')->middleware('auth');

    // Menghapus produk dari keranjang
    Route::delete('/cart/{cartId}', [UserCartController::class, 'removeFromCart'])->name('cart.remove')->middleware('auth');

    Route::post('/cart/bulk-remove', [UserCartController::class, 'removeSelectedItems'])->name('cart.bulkRemove')->middleware('auth');

    // Route checkout
    Route::post('/checkout', [UserCheckoutController::class, 'index'])->name('checkout.index')->middleware('auth');
    Route::post('/midtrans/snap', [UserCheckoutController::class, 'getSnapToken'])->name('api.midtrans.snap')->middleware('auth');
    Route::post('/midtrans/payment-success', [UserCheckoutController::class, 'handlePaymentSuccess'])->middleware('auth');
    Route::get('/midtrans/snap-token', [UserCheckoutController::class, 'SnapToken'])->middleware('auth');

    Route::get('/order-history', [UserOrderController::class, 'index'])->middleware('auth')->name('order.index');
    Route::get('/snap-token', [UserOrderController::class, 'SnapToken'])->middleware('auth');
    Route::post('/payment-success', [UserOrderController::class, 'handlePaymentSuccess'])->middleware('auth');
});

Route::post('/save-address', [UserController::class, 'saveAddress'])->middleware('auth');
Route::delete('/delete-address', [UserController::class, 'deleteAddress'])->middleware('auth');
Route::post('/api/midtrans/snap', [UserCheckoutController::class, 'getSnapToken'])->name('api.midtrans.snap');
// Auth routes (login, register, logout)
Auth::routes();

