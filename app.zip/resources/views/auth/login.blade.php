@extends('layouts.home')

@section('content')

<div class="container-fluid d-flex justify-content-center align-items-center">
    <div class="card" style="width: 400px;">
        <div class="card-header text-center">
            <h4 class="mb-0">Login</h4>
        </div>
        <div class="card-body">
            <form method="POST" action="{{ route('login') }}">
                @csrf

                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" name="email" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label for="password_confirmation" class="form-label">Ulang Password</label>
                    <input type="password" name="password_confirmation" class="form-control" required>
                </div>

                @if (Route::has('password.request'))
                                <div class="text-center">
                                    <a class="small" href="{{ route('password.request') }}">Forgot Password?</a>
                                </div>
                                @endif

                <button type="submit" class="btn btn-primary btn-block mt-3">Login</button>
                <a href="{{ route('register') }}" class="btn btn-success btn-block mt-2">Register</a>
            </form>
        </div>
    </div>
</div>

@endsection
