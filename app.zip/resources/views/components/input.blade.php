<div class="mb-3">
    <label for="{{ $inputName }}">{{ $label }}</label>
    <input type="{{ $inputType }}" name="{{ $inputName }}" class="{{ $inputClass }}" placeholder="{{ $placeholder }}">
</div>
