<button type="{{ $buttonType }}" class="{{ $className }}">
    {{ $label }}
</button>
