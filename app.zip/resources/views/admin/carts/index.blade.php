@extends('layouts.admin')

@section('content')
    <div class="container">
        <h2>Carts</h2>

        <!-- Tabel Transaksi -->
        <table class="table table-bordered mt-4">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>User Id</th>
                    <th>Product Id</th>
                    <th>Size</th>
                    <th>Quantity</th>
                </tr>
            </thead>
            <tbody>
                @foreach($carts as $cart)
                    <tr>
                        <td>{{ $cart->id }}</td>
                        <td>{{ $cart->user_id }}</td>
                        <td>{{ $cart->product_id }}</td>
                        <td>{{ $cart->size }}</td>
                        <td>{{ $cart->quantity }}</td>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
