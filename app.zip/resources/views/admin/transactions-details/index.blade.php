@extends('layouts.admin')

@section('content')
    <div class="container">
        <h2>Transactions Details</h2>

        <!-- Tabel Transaksi -->
        <table class="table table-bordered mt-4">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Transaction Id</th>
                    <th>Product Id</th>
                    <th>Quantity</th>
                    <th>Price</th>
                    <th>Subtotal</th>
                    <th>Transaction Time</th>
                </tr>
            </thead>
            <tbody>
                @foreach($transactions_details as $transactions)
                    <tr>
                        <td>{{ $transactions->id }}</td>
                        <td>{{ $transactions->transaction_id }}</td>
                        <td>{{ $transactions->product_id }}</td>
                        <td>{{ $transactions->quantity }}</td>
                        <td>{{ number_format($transactions->price, 2) }}</td>
                        <td>{{ number_format($transactions->subtotal, 2) }}</td>
                        <td>{{ $transactions->created_at }}</td>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
