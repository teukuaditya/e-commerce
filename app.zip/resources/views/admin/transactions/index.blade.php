@extends('layouts.admin')

@section('content')
    <div class="container">
        <h2>Transactions</h2>

        <!-- Tabel Transaksi -->
        <table class="table table-bordered mt-4">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Order ID</th>
                    <th>Customer Name</th>
                    <th>Gross Amount</th>
                    <th>Courier</th>
                    <th>Service</th>
                    <th>Transaction Time</th>
                    <th>Payment Type</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                @foreach($transactions as $transaction)
                    <tr>
                        <td>{{ $transaction->id }}</td>
                        <td>{{ $transaction->order_id }}</td>
                        <td>{{ $transaction->customer_name }}</td>
                        <td>{{ number_format($transaction->gross_amount, 2) }}</td>
                        <td>{{ $transaction->courier }}</td>
                        <td>{{ $transaction->courier_service }}</td>
                        <td>{{ $transaction->transaction_time }}</td>
                        <td>{{ $transaction->payment_type }}</td>
                        <td>{{ ucfirst($transaction->transaction_status) }}</td>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
