<!-- Header -->
<header>
<!-- Header Mobile -->
<div class="wrap-header-mobile">
    <!-- Logo moblie -->
    <a href="{{ route('user.home') }}" class="logo-mobile">
        <span style="font-size: 25px; font-weight: bold; color: #000; letter-spacing: 2px;">FLEXORA</span>
    </a>

    <!-- Icon header -->
    <div class="wrap-icon-header flex-w flex-r-m m-r-15">
        <div class="icon-header-item cl2 hov-cl1 trans-04 p-r-11 js-show-modal-search">
            <i class="zmdi zmdi-search"></i>
        </div>

        <a href="{{ route('user.cart.index') }}">
            <div class="icon-header-item cl2 hov-cl1 trans-04 p-l-22 p-r-11 icon-header-noti js-show-cart"
                 data-notify="{{ $cartCount }}">
                <i class="zmdi zmdi-shopping-cart"></i>
            </div>
        </a>

        <a href="#" class="dis-block icon-header-item cl2 hov-cl1 trans-04 p-r-11 p-l-10 icon-header-noti" data-notify="0">
            <i class="zmdi zmdi-favorite-outline"></i>
        </a>
    </div>

    <!-- Button show menu -->
    <div class="btn-show-menu-mobile hamburger hamburger--squeeze">
        <span class="hamburger-box">
            <span class="hamburger-inner"></span>
        </span>
    </div>
</div>


<!-- Menu Mobile -->
<div class="menu-mobile">

    <ul class="main-menu-m">
        <li class="{{ Route::currentRouteName() == 'user.home' ? 'active-menu' : '' }}">
            <a href="{{ route('user.home') }}">Home</a>
        </li>

        <li class="{{ Route::currentRouteName() == 'user.products.index' ? 'active-menu' : '' }}">
            <a href="{{ route('user.products.index') }}">Product</a>
        </li>

        <li class="{{ Route::currentRouteName() == 'user.categories.index' ? 'active-menu' : '' }}">
            <a href="{{ route('user.categories.index') }}">Category</a>
            <ul class="sub-menu">
                @foreach($categories as $category)
                    <li><a href="{{ route('user.categories.products', $category->id) }}">{{ $category->category_name }}</a></li>
                @endforeach
            </ul>
        </li>

        <li class="{{ Route::currentRouteName() == 'blog' ? 'active-menu' : '' }}">
            <a href="">Blog</a>
        </li>

        <li class="{{ Route::currentRouteName() == 'about' ? 'active-menu' : '' }}">
            <a href="">About</a>
        </li>

        <li class="{{ Route::currentRouteName() == 'contact' ? 'active-menu' : '' }}">
            <a href="">Contact</a>
        </li>
    </ul>
</div>
</header>
