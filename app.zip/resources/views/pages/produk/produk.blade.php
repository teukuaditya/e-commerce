@extends('layouts.app')

@section('content')
    <h1 class="h1 mb-4 text-dark">Produk</h1>

    @if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    @if ($errors->any())
        <div class="alert alert-danger">
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </div>
    @endif
    <a href="{{ route('dashboard.produk.create') }}" class="btn btn-primary mb-3">Tambah Produk</a>
    <div class="row">
        @foreach ($produk as $item)
            <div class="col-md-3 mb-4">
                <div class="card h-100">
                    @if ($item->foto_produk)
                        <img src="{{ asset('storage/' . $item->foto_produk) }}" class="card-img-top" alt="Foto Produk">
                    @else
                        <div class="card-body text-center">
                            <p>Tidak ada foto</p>
                        </div>
                    @endif
                    <div class="card-body">
                        <span class="badge badge-primary"
                            style="color: white; margin-bottom: 10px; font-size: 12px">{{ $item->kategori->nama }}</span>
                        <h5 class="card-title text-dark" style="font-size: 18px;"><strong>{{ $item->nama }}</strong></h5>
                        <p class="card-text text-dark" style="font-size: 14px;">{{ $item->deskripsi }}</p>
                        <p class="card-text text-dark" style="font-size: 16px;">
                            <strong>{{ 'Rp ' . number_format($item->harga, 0, ',', '.') }}</strong>
                        </p>
                        <div class="d-flex justify-content-start" style="margin-top: 10px">
                            <a href="{{ route('dashboard.produk.edit', $item->id) }}"
                                class="btn btn-warning btn-sm mr-2">Edit</a>
                            <form action="{{ route('dashboard.produk.destroy', $item->id) }}" method="POST"
                                style="display:inline;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger btn-sm"
                                    onclick="return confirm('Yakin ingin menghapus produk ini?')">Hapus</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
@endsection

