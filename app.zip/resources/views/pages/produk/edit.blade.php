@extends('layouts.app')

@section('content')
    <h1>Edit Produk</h1>

    @if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    @if ($errors->any())
        <div class="alert alert-danger">
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </div>
    @endif

    <form action="{{ route('dashboard.produk.update', $produk->id) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')
        <div class="form-group">
            <label for="nama">Nama Produk</label>
            <input type="text" class="form-control" id="nama" name="nama" value="{{ $produk->nama }}" required>
        </div>
        <div class="form-group">
            <label for="kategori">Kategori</label>
            <select name="kategori_id" id="kategori" class="form-control">
                @foreach ($kategori as $item)
                    <option value="{{ $item->id }}" {{ $item->id == $produk->kategori_id ? 'selected' : '' }}>
                        {{ $item->nama }}</option>
                @endforeach
            </select>
        </div>
        <div class="form-group">
            <label for="harga">Harga</label>
            <input type="number" class="form-control" id="harga" name="harga" value="{{ $produk->harga }}" required>
        </div>
        <div class="form-group">
            <label for="foto_produk">Foto Produk</label>
            <input type="file" class="form-control" id="foto_produk" name="foto_produk">
            <img src="{{ asset('storage/' . $produk->foto_produk) }}" alt="{{ basename($produk->foto_produk) }}"
                width="100">
        </div>
        <div class="form-group">
            <label for="deskripsi">Deskripsi</label>
            <textarea class="form-control" id="deskripsi" name="deskripsi">{{ $produk->deskripsi }}</textarea>
        </div>
        <div class="d-flex justify-content-start">
            <button type="submit" class="btn btn-primary mr-2">Update</button>
            <a href="{{ route('dashboard.produk.index') }}" class="btn btn-secondary">Batal</a>
        </div>
    </form>
@endsection
