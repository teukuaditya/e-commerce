@extends('layouts.app')

@section('content')
    <h1 class="h1 mb-4 text-dark">Transaksi</h1>

    @if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    @if ($errors->any())
        <div class="alert alert-danger">
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </div>
    @endif
    <a href="{{ route('dashboard.transaksi.create') }}" class="btn btn-primary mb-3">Tambah Transaksi</a>
    @csrf
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>No</th>
                <th>Pelanggan</th>
                <th>Produk</th>
                <th>Total Harga</th>
                <th>Nomor Invoice</th>
                <th>Status Pembayaran</th>
                <th>Tanggal Pembelian</th>
                <th>Tanggal Pembayaran</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($transaksi as $item)
                <tr>
                    <td>{{ $loop->iteration }}</td>
                    <td>{{ $item->pelanggan->nama_lengkap }}</td>
                    <td>{{ $item->produk->nama }}</td>
                    <td>{{ number_format($item->total_harga, 2) }}</td>
                    <td>{{ $item->nomor_invoice }}</td>
                    <td>{{ $item->status_pembayaran }}</td>
                    <td>{{ \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $item->tanggal_pembelian)->format('d-m-Y') }}
                    </td>
                    <td>
                        {{ $item->tanggal_pembayaran ? \Carbon\Carbon::parse($item->tanggal_pembayaran)->format('d-m-Y') : 'Belum dibayar' }}
                    </td>
                    <td>
                        <a href="{{ route('dashboard.transaksi.edit', $item->id) }}" class="btn btn-warning btn-sm">Edit</a>
                        <form action="{{ route('dashboard.transaksi.destroy', $item->id) }}" method="POST"
                            style="display:inline;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger btn-sm"
                                onclick="return confirm('Yakin ingin menghapus transaksi ini?')">Hapus</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
@endsection
