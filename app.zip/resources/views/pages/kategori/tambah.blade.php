@extends('layouts.app')

@section('content')
    <h1>Tambah Kategori</h1>

    @if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    @if ($errors->any())
        <div class="alert alert-danger">
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </div>
    @endif

    <form action="{{ route('dashboard.kategori.store') }}" method="POST">
        @csrf
        <div class="form-group">
            <label for="nama">Nama Kategori</label>
            <input type="text" class="form-control" id="nama" name="nama" required>
        </div>
        <div class="form-group">
            <label for="keterangan">Keterangan</label>
            <textarea class="form-control" id="keterangan" name="keterangan"></textarea>
        </div>
        <div class="d-flex justify-content-start">
            <button type="submit" class="btn btn-primary mr-2">Simpan</button>
            <a href="{{ route('dashboard.kategori.index') }}" class="btn btn-secondary">Batal</a>
        </div>
    </form>
@endsection
