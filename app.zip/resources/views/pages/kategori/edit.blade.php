@extends('layouts.app')

@section('content')
    <h1>Edit Kategori</h1>

    @if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    @if ($errors->any())
        <div class="alert alert-danger">
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </div>
    @endif

    <form action="{{ route('dashboard.kategori.update', $kategori->id) }}" method="POST">
        @csrf
        @method('PUT')

        <div class="form-group">
            <label for="nama">Nama Kategori</label>
            <input type="text" class="form-control" id="nama" name="nama" value="{{ $kategori->nama }}" required>
        </div>
        <div class="form-group">
            <label for="keterangan">Keterangan</label>
            <textarea class="form-control" id="keterangan" name="keterangan">{{ $kategori->keterangan }}</textarea>
        </div>
        <div class="d-flex justify-content-start">
            <button type="submit" class="btn btn-primary mr-2">Update</button>
            <a href="{{ route('dashboard.kategori.index') }}" class="btn btn-secondary">Batal</a>
        </div>
    </form>
@endsection
