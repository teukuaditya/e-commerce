@extends('layouts.app')

@section('content')
    <h1 class="h1 mb-4 text-dark">Kategori</h1>

    @if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    @if ($errors->any())
        <div class="alert alert-danger">
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </div>
    @endif

    <a href="{{ route('dashboard.kategori.create') }}" class="btn btn-primary mb-3">Tambah Kategori</a>
    <div class="row">
        @foreach ($kategori as $kat)
            <div class="col-md-2 mb-4">
                <div class="card w-100">
                    <div class="card-body">
                        <h5 class="card-title"><strong>{{ $kat->nama }}</strong></h5>
                        <p class="card-text">{{ $kat->keterangan }}</p>
                    </div>
                    <div class="card-footer text-center">
                        <a href="{{ route('dashboard.kategori.edit', $kat->id) }}" class="btn btn-warning btn-sm">Edit</a>
                        <form action="{{ route('dashboard.kategori.destroy', $kat->id) }}" method="POST"
                            style="display:inline-block;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger btn-sm"
                                onclick="return confirm('Yakin ingin menghapus kategori ini?')">Hapus</button>
                        </form>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
@endsection
