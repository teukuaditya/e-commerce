@extends('layouts.app')

@section('content')
    <h2>Tambah Pelanggan</h2>

    @if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    @if ($errors->any())
        <div class="alert alert-danger">
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </div>
    @endif

    <form action="{{ route('dashboard.pelanggan.store') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="form-group">
            <label for="nama_lengkap">Nama Lengkap:</label>
            <input type="text" name="nama_lengkap" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="jenis_kelamin">Jenis Kelamin:</label>
            <select name="jenis_kelamin" class="form-control" required>
                <option value="L">Laki-laki</option>
                <option value="P">Perempuan</option>
            </select>
        </div>

        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" name="email" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="nomor_hp">Nomor HP:</label>
            <input type="text" name="nomor_hp" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="alamat">Alamat:</label>
            <textarea name="alamat" class="form-control"></textarea>
        </div>

        <div class="form-group">
            <label for="foto_profil">Foto Profil:</label>
            <input type="file" name="foto_profil" class="form-control">
        </div>

        <div class="d-flex justify-content-start">
            <button type="submit" class="btn btn-primary mr-2">Simpan</button>
            <a href="{{ route('dashboard.pelanggan.index') }}" class="btn btn-secondary">Batal</a>
        </div>
    </form>
@endsection
