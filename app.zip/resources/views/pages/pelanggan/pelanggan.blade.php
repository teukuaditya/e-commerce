@extends('layouts.app')

@section('content')
    <h1 class="h1 mb-4 text-dark">Pelanggan</h1>

    @if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    @if ($errors->any())
        <div class="alert alert-danger">
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </div>
    @endif

    <a href="{{ route('dashboard.pelanggan.create') }}" class="btn btn-primary mb-3">Tambah Pelanggan</a>

    <div class="row">
        @foreach ($pelanggan as $p)
            <div class="col-md-4 mb-4">
                <div class="card h-100">
                    <div class="card-body">
                        <p class="card-title"><strong>Nama:</strong> {{ $p->nama_lengkap }}</p>
                        <p class="card-text"><strong>Jenis Kelamin:</strong>
                            {{ $p->jenis_kelamin == 'L' ? 'Laki-laki' : 'Perempuan' }}</p>
                        <p class="card-text"><strong>Email:</strong> {{ $p->email }}</p>
                        <p class="card-text"><strong>Nomor HP:</strong> {{ $p->nomor_hp }}</p>
                        <p class="card-text"><strong>Alamat:</strong> {{ $p->alamat }}</p>
                        <div class="text-center">
                            @if ($p->foto_profil)
                                <img src="{{ asset('storage/' . $p->foto_profil) }}" class="img-fluid" alt="Foto Profil"
                                    style="max-height: 150px;">
                            @else
                                <p>Tidak ada foto</p>
                            @endif
                        </div>
                    </div>
                    <div class="card-footer text-center">
                        <a href="{{ route('dashboard.pelanggan.edit', $p->id) }}" class="btn btn-warning btn-sm">Edit</a>
                        <form action="{{ route('dashboard.pelanggan.destroy', $p->id) }}" method="POST"
                            style="display: inline-block;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger btn-sm"
                                onclick="return confirm('Yakin ingin menghapus pelanggan ini?')">Hapus</button>
                        </form>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
@endsection
