@extends('layouts.app')

@section('content')
    <h2>Edit Pelanggan</h2>

    @if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    @if ($errors->any())
        <div class="alert alert-danger">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
        </div>
    @endif

    <form action="{{ route('dashboard.pelanggan.update', $pelanggan->id) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')

        <div class="form-group">
            <label for="nama_lengkap">Nama Lengkap:</label>
            <input type="text" name="nama_lengkap" class="form-control" value="{{ $pelanggan->nama_lengkap }}" required>
        </div>

        <div class="form-group">
            <label for="jenis_kelamin">Jenis Kelamin:</label>
            <select name="jenis_kelamin" class="form-control" required>
                <option value="L" {{ $pelanggan->jenis_kelamin == 'L' ? 'selected' : '' }}>Laki-laki</option>
                <option value="P" {{ $pelanggan->jenis_kelamin == 'P' ? 'selected' : '' }}>Perempuan</option>
            </select>
        </div>

        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" name="email" class="form-control" value="{{ $pelanggan->email }}" required>
        </div>

        <div class="form-group">
            <label for="nomor_hp">Nomor HP:</label>
            <input type="text" name="nomor_hp" class="form-control" value="{{ $pelanggan->nomor_hp }}" required>
        </div>

        <div class="form-group">
            <label for="alamat">Alamat:</label>
            <textarea name="alamat" class="form-control">{{ $pelanggan->alamat }}</textarea>
        </div>

        <div class="form-group">
            <label for="foto_profil">Foto Profil (Opsional):</label>
            <input type="file" name="foto_profil" class="form-control">
            @if ($pelanggan->foto_profil)
                <img src="{{ asset('uploads/foto_profil/' . $pelanggan->foto_profil) }}"
                    alt="{{ basename($pelanggan->foto_profil) }}" width="50">
            @endif
        </div>
        <div class="d-flex justify-content-start">
            <button type="submit" class="btn btn-primary mr-2">Update</button>
            <a href="{{ route('dashboard.pelanggan.index') }}" class="btn btn-secondary">Batal</a>
        </div>
    </form>
@endsection
