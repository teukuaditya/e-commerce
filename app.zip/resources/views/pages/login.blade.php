<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
</head>

<div class="container-fluid vh-100 d-flex justify-content-center align-items-center" style="">
    <div class="card" style="width: 300px;">
        <div class="card-body">
            <form method="POST" action="{{ route('login') }}">
                @csrf
                <x-input inputType="email" inputName="email" inputClass="form-control" placeholder="email@arkatama.id"
                    label="Email" />
                <x-input inputType="password" inputName="password" inputClass="form-control" placeholder="********"
                    label="Password" />
                <x-input inputType="password" inputName="password_confirmation" inputClass="form-control"
                    placeholder="********" label="Ulang Password" />
                <x-button className="btn btn-primary btn-block" buttonType="submit" label="Login" />
                <x-button className="btn btn-success btn-block mt-2" buttonType="button" label="Register" />
            </form>
        </div>
    </div>
</div>

</html>
