<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Kategori;
use Symfony\Component\HttpFoundation\Response;

class KategoriController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $kategori = Kategori::all();
        $data = [
            "message" => "Data kategori berhasil diambil",
            "data" => $kategori,
        ];
        return response()->json($data, Response::HTTP_OK);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        try {
            $request->validate([
                "nama" => ["required"],
                "keterangan" => ["required"]
            ], [
                "nama.required" => "Nama kategori harus diisi",
                "keterangan.required" => "Keterangan kategori harus diisi"
            ]);

            Kategori::insert([
                "nama" => $request->nama,
                "keterangan" => $request->keterangan
            ]);

            return response()->json([
                "message" => "Data kategori berhasil ditambahkan",
            ], Response::HTTP_CREATED);

        } catch (\Throwable $th) {
            return response()->json([
                "message" => "Data kategori gagal ditambahkan",
                "error" => $th->getMessage(),
            ], Response::HTTP_BAD_REQUEST);
        }

    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $kategori = Kategori::find($id);
        $data = [
            "message" => "Data kategori berhasil diambil",
            "data" => $kategori,
        ];
        return response()->json($data, Response::HTTP_OK);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, int $id)
    {
        try {
            $request->validate([
                "nama" => ["required"],
                "keterangan" => ["required"]
            ], [
                "nama.required" => "Nama kategori harus diisi",
                "keterangan.required" => "Keterangan kategori harus diisi"
            ]);

            Kategori::where("id", $id)->update([
                "nama" => $request->nama,
                "keterangan" => $request->keterangan
            ]);

            return response()->json([
                "message" => "Data kategori berhasil diubah"
            ], Response::HTTP_OK);

        } catch (\Throwable $th) {
            return response()->json([
                "message" => "Data kategori gagal diubah",
                "error" => $th->getMessage(),
            ], Response::HTTP_BAD_REQUEST);
        }

    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        try {
            $kategori = Kategori::where("id", $id)->first();

            if (!$kategori) {
                return response()->json([
                    "message" => "Data kategori tidak ditemukan"
                ], Response::HTTP_NOT_FOUND);
            }

            $kategori->delete();

            return response()->json([
                "message" => "Data kategori berhasil dihapus"
            ], Response::HTTP_OK);

        } catch (\Throwable $th) {
            return response()->json([
                "message" => "Data kategori gagal dihapus",
                "error" => $th->getMessage(),
            ], Response::HTTP_BAD_REQUEST);
        }

    }

    public function getKategoriDenganTotalProduk()
    {
        $kategori = Kategori::withCount('produk')
            ->get(['id', 'nama']);

        return response()->json($kategori);
    }

}
