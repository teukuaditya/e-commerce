<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Transaction;
use Midtrans\Config;
use Midtrans\Snap;

class MidtransController extends Controller
{
    public function callback(Request $request): \Illuminate\Http\JsonResponse
    {
        $transaction = Transaction::where('order_id', $request->order_id)->first();
        if (!$transaction) {
            return response()->json(['status' => 'error', 'message' => 'Transaction not found'], 200);
        }
        $transaction->payment_type = $request->payment_type;
        $transaction->payment_method = $this->getPaymentMethod($request);
        // Jika transaksi berhasil
        if ($request->transaction_status == "settlement") {
            $transaction->transaction_status = "success";
            $transaction->save();
            // Jika transaksi pending
        } else if ($request->transaction_status == "pending") {
            $transaction->transaction_status = "pending";
            $transaction->save();
            // jika transaksi gagal
        } else {
            $transaction->transaction_status = "failed";
            $transaction->save();
        }
        return response()->json(['status' => 'success']);
    }

//     public function getSnapToken(Request $request)
// {
//     // Trim dan set kunci API
//     Config::$serverKey = trim(env('MIDTRANS_SERVER_KEY'));
//     Config::$clientKey = trim(env('MIDTRANS_CLIENT_KEY'));
//     Config::$isProduction = false; // Set ke true jika sudah di produksi
//     Config::$isSanitized = true;
//     Config::$is3ds = true;

//     // Debugging jika serverKey kosong
//     if (empty(Config::$serverKey)) {
//         return response()->json(['error' => 'ServerKey is missing or invalid.'], 500);
//     }

//     // Pastikan data ada di request
//     if (!$request->order_id || !$request->gross_amount || !$request->customer_details) {
//         return response()->json(['error' => 'Missing required parameters.'], 400);
//     }

//     // Menyiapkan parameter transaksi
//     $params = [
//         'transaction_details' => [
//             'order_id' => $request->order_id,
//             'gross_amount' => $request->gross_amount,
//         ],
//         'customer_details' => [
//             'first_name' => $request->customer_details['first_name'],
//             'email' => $request->customer_details['email'],
//             'phone' => $request->customer_details['phone'],
//         ],
//         'item_details' => array_map(function ($item) {
//             return [
//                 'id' => $item['id'], // ID produk, pastikan ini ada di frontend
//                 'quantity' => $item['quantity'], // Jumlah produk
//                 'name' => $item['product_brand']. ' - ' . $item['product_title']. ' - ' . $item['product_size'], // Nama produk, sesuai dengan yang dikirim dari frontend
//                 'price' => $item['price'], // Harga per unit produk
//             ];
//         }, $request->items), // Pastikan Anda mengirimkan data `items` dalam request
//     ];

//     // Menambahkan Ongkos Kirim sebagai item baru
//     if (isset($request->shipping_cost) && $request->shipping_cost > 0) {
//         $params['item_details'][] = [
//             'id' => 'shipping', // ID untuk ongkos kirim
//             'quantity' => 1, // Jumlah hanya 1
//             'name' => 'Shipping ('.$request->courier.' - '.$request->service.')', // Nama layanan pengiriman
//             'price' => $request->shipping_cost, // Biaya pengiriman
//         ];
//     }

//     try {
//         // Mendapatkan snap token
//         $snapToken = Snap::getSnapToken($params);
//         return response()->json(['token' => $snapToken]);
//     } catch (\Exception $e) {
//         // Menangani kesalahan jika terjadi
//         return response()->json(['error' => $e->getMessage()], 500);
//     }
// }

    private function getPaymentMethod($callback): string
    {
        if ($callback->payment_type == 'credit_card') {
            return 'Credit Card';
        } else if ($callback->payment_type == 'bank_transfer') {
            return $callback->va_numbers[0]->bank;
        } else if ($callback->payment_type == 'echannel') {
            return 'Mandiri';
        } else if ($callback->payment_type == 'qris') {
            return $callback->acquirer;
        } else if ($callback->payment_type == 'cstore') {
            return $callback->store;
        } else {
            return 'Unknown';
        }
    }
}


function callback () : void {

}
