<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Cart;
use Illuminate\Support\Facades\Auth;
use GuzzleHttp\Client;
use Midtrans\Config;
use Midtrans\Snap;
use Illuminate\Http\Request;

class CheckoutController extends Controller
{
    public function index()
    {
        // Ambil data cart untuk user yang sedang login
        // Mengambil cart items berdasarkan id produk yang dipilih
        $selectedItemIds = request('cartItems') ? explode(',', request('cartItems')) : [];
        $cartItems = Cart::whereIn('id', $selectedItemIds)->where('user_id', Auth::id())->with('product')->get();

        // Menghitung total cart
        $cartTotal = $cartItems->sum(function ($item) {
            return $item->product->price * $item->quantity;
        });

        // Panggil API RajaOngkir untuk mendapatkan daftar provinsi
        $client = new Client();
        $response = $client->request('GET', 'https://api.rajaongkir.com/starter/province', [
            'headers' => [
                'key' => env('RAJAONGKIR_API_KEY'), // Ganti dengan API Key Anda
            ],
        ]);

        $provinces = json_decode($response->getBody()->getContents(), true)['rajaongkir']['results'];

        // Ambil alamat pengguna yang sedang login dari kolom address di tabel users
        $user = Auth::user();
        $address = $user->address;

        // Pisahkan alamat menjadi provinsi dan kota
        $addressParts = explode(',', $address);
        $province = isset($addressParts[0]) ? trim($addressParts[0]) : null; // Ambil provinsi
        $city = isset($addressParts[1]) ? trim($addressParts[1]) : null; // Ambil kota jika ada

        // Menangkap City ID menggunakan regex (misalnya City ID: 41)
        $cityId = null;
        if (preg_match('/City ID: (\d+)/', $address, $matches)) {
            $cityId = $matches[1]; // Ambil City ID dari hasil regex
        }

        // Mengirimkan data cartItems, cartTotal, provinces, dan cityId ke view
        return view('user.checkout.index', compact('cartItems', 'cartTotal', 'provinces', 'cityId'));
    }

    public function getSnapToken(Request $request)
    {
        // Trim dan set kunci API
        Config::$serverKey = trim(env('MIDTRANS_SERVER_KEY'));
        Config::$clientKey = trim(env('MIDTRANS_CLIENT_KEY'));
        Config::$isProduction = false; // Set ke true jika sudah di produksi
        Config::$isSanitized = true;
        Config::$is3ds = true;

        // Debugging jika serverKey kosong
        if (empty(Config::$serverKey)) {
            return response()->json(['error' => 'ServerKey is missing or invalid.'], 500);
        }

        // Pastikan data ada di request
        if (!$request->order_id || !$request->gross_amount || !$request->customer_details) {
            return response()->json(['error' => 'Missing required parameters.'], 400);
        }

        // Menyiapkan parameter transaksi
        $params = [
            'transaction_details' => [
                'order_id' => $request->order_id,
                'gross_amount' => $request->gross_amount,
            ],
            'customer_details' => [
                'first_name' => $request->customer_details['first_name'],
                'email' => $request->customer_details['email'],
                'phone' => $request->customer_details['phone'],
            ],
            'item_details' => array_map(function ($item) {
                return [
                    'id' => $item['id'], // ID produk, pastikan ini ada di frontend
                    'quantity' => $item['quantity'], // Jumlah produk
                    'name' => $item['product_brand'] . ' - ' . $item['product_title'] . ' - ' . $item['product_size'], // Nama produk, sesuai dengan yang dikirim dari frontend
                    'price' => $item['price'], // Harga per unit produk
                ];
            }, $request->items), // Pastikan Anda mengirimkan data `items` dalam request
            'customer_name' => $request->customer_details['first_name'], // Pastikan customer_name ada
        ];

        // Menambahkan Ongkos Kirim sebagai item baru
        if (isset($request->shipping_cost) && $request->shipping_cost > 0) {
            $params['item_details'][] = [
                'id' => 'shipping', // ID untuk ongkos kirim
                'quantity' => 1, // Jumlah hanya 1
                'name' => 'Shipping (' . $request->courier . ' - ' . $request->service . ')', // Nama layanan pengiriman
                'price' => $request->shipping_cost, // Biaya pengiriman
            ];
        }

        try {
            // Mendapatkan snap token
            $snapToken = Snap::getSnapToken($params);
            return response()->json(['token' => $snapToken]);
        } catch (\Exception $e) {
            // Menangani kesalahan jika terjadi
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function handlePaymentSuccess(Request $request)
    {

        \Log::info('Received request data:', ['request' => $request->all()]);
        // Cek apakah transaksi sudah ada berdasarkan order_id
    $transaction = \App\Models\Transaction::where('order_id', $request->order_id)->first();

    if (!$transaction) {
        // Jika transaksi tidak ditemukan, buat transaksi baru
        $transaction = new \App\Models\Transaction();
        $transaction->order_id = $request->order_id;
        $transaction->user_id = Auth::id(); // Menyimpan ID user yang login
        $transaction->gross_amount = $request->gross_amount;
        $transaction->payment_type = $request->payment_type; // Jenis pembayaran (credit_card, ewallet, dll)
        $transaction->transaction_status = $request->transaction_status; // Status transaksi, misalnya 'pending'
        $transaction->transaction_time = now(); // Set waktu transaksi
        $transaction->customer_name = $request->customer_name; // Menyimpan nama customer
        $transaction->courier = $request->courier; // Simpan kurir
        $transaction->courier_service = $request->courier_service; // Simpan layanan pengiriman
        $transaction->snap_token = $request->snap_token; // Simpan snap_token yang diterima
        $transaction->save();
    } else {
        // Jika transaksi sudah ada, hanya update statusnya
        $transaction->payment_type = $request->payment_type;
        $transaction->transaction_status = $request->transaction_status;
        $transaction->save();
    }

    if (isset($request->items) && is_array($request->items)) {
        $productIds = collect($request->items)->pluck('id')->toArray(); // Ambil semua product_id
        Cart::where('user_id', Auth::id())
            ->whereIn('product_id', $productIds)
            ->delete(); // Hapus produk yang telah di-checkout dari keranjang
    }

    // Periksa status transaksi (hanya simpan jika statusnya 'settlement')
    if (in_array($request->transaction_status, ['settlement', 'pending'])) {
        // Pastikan $request->items ada dan berupa array
        if (isset($request->items) && is_array($request->items)) {
            // Menyimpan setiap item transaksi ke tabel transaction_details
            foreach ($request->items as $item) {
                \App\Models\TransactionDetail::create([
                    'transaction_id' => $transaction->id,  // Menghubungkan dengan transaksi yang baru dibuat
                    'product_id' => $item['id'],  // ID produk dari item
                    'quantity' => $item['quantity'],  // Jumlah produk
                    'price' => $item['price'],  // Harga per unit produk
                    'subtotal' => $item['quantity'] * $item['price'],  // Subtotal (harga x quantity)
                ]);
            }
        } else {
            return response()->json(['error' => 'Items data missing or invalid.'], 400);
        }
    } else {
        // Jika status bukan 'settlement', kita tidak simpan transaction details
        \Log::info('Transaction not settled, skipping item details insertion.');
    }

    // Menyimpan status transaksi sebagai pending atau sesuai status dari Midtrans
    return response()->json(['success' => 'Transaction status updated successfully.']);
}

public function SnapToken(Request $request)
{
    $transaction = \App\Models\Transaction::where('order_id', $request->order_id)->first();

    if (!$transaction || !$transaction->snap_token) {
        return response()->json(['error' => 'Transaction or Snap Token not found.'], 404);
    }

    return response()->json(['snap_token' => $transaction->snap_token]);
}


}
