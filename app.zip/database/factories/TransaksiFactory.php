<?php

namespace Database\Factories;

use App\Models\Transaksi;
use App\Models\Pelanggan;
use App\Models\Produk;
use Illuminate\Database\Eloquent\Factories\Factory;

class TransaksiFactory extends Factory
{
    protected $model = Transaksi::class;

    public function definition()
    {
        return [
            'pelanggan_id' => Pelanggan::inRandomOrder()->first()->id,
            'total_harga' => $this->faker->randomFloat(2, 10000, 1000000),
            'produk_id' => Produk::inRandomOrder()->first()->id,
            'deskripsi' => $this->faker->sentence(),
            'nomor_invoice' => $this->faker->unique()->bothify('INV-#####'),
            'status_pembayaran' => $this->faker->randomElement(['belum_bayar', 'sudah_bayar']),
            'tanggal_pembelian' => now(),
            'tanggal_pembayaran' => $this->faker->optional(0.7, null)->dateTimeBetween('-1 month', 'now'),
        ];
    }
}

