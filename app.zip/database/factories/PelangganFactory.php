<?php

namespace Database\Factories;

use App\Models\Pelanggan;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Facades\File;

class PelangganFactory extends Factory
{
    protected $model = Pelanggan::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        // Mendapatkan path folder produk
        $directory = storage_path('app/public/profil');
        // Mengambil semua file dari folder produk
        $files = File::files($directory);

        // Memilih file foto secara acak dari folder produk
        $randomFile = $this->faker->randomElement($files);
        $fileName = basename($randomFile); // Mengambil nama file

        return [
            'nama_lengkap' => $this->faker->name,
            'jenis_kelamin' => $this->faker->randomElement(['L', 'P']),
            'email' => $this->faker->unique()->safeEmail,
            'nomor_hp' => $this->faker->phoneNumber,
            'alamat' => $this->faker->address,
            'foto_profil' => 'profil/' . $fileName, // Menyimpan path foto profil relatif
        ];
    }
}
