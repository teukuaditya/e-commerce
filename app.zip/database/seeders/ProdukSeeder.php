<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use App\Models\Produk;
use Faker\Factory as Faker;

class ProdukSeeder extends Seeder
{
    public function run()
    {
        $faker = Faker::create();
        $directory = storage_path('app/public/produk');
        $files = File::files($directory);

        foreach (range(1, 100) as $index) {
            $randomFile = $faker->randomElement($files);
            $fileName = basename($randomFile);

            $harga = $faker->randomFloat(0, 10000, 100000);
            $hargaFormatted = (int) $harga;

            Produk::create([
                'kategori_id' => $faker->numberBetween(1, 3),
                'nama' => $faker->word,
                'harga' => $hargaFormatted,
                'foto_produk' => 'produk/' . $fileName,
                'deskripsi' => $faker->sentence(4),
            ]);
        }
    }
}
