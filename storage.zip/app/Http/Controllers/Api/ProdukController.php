<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Produk;
use Symfony\Component\HttpFoundation\Response;

class ProdukController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $produk = Produk::all();
        $data = [
            "message" => "Data produk berhasil diambil",
            "data" => $produk,
        ];
        return response()->json($data, Response::HTTP_OK);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        try {
            $request->validate([
                "kategori_id" => ["required", "exists:kategori,id"],
                "nama" => ["required"],
                "harga" => ["required", "numeric"],
                "foto_produk" => ["required", "string"],
                "deskripsi" => ["required", "string"]
            ], [
                "nama.required" => "Nama produk harus diisi",
                "harga.required" => "Harga produk harus diisi",
                "harga.numeric" => "Harga produk harus berupa angka",
                "foto_produk.required" => "Foto produk harus diisi",
                "deskripsi.required" => "Deskripsi produk harus diisi"
            ]);

            $produk = Produk::create([
                "kategori_id" => $request->kategori_id,
                "nama" => $request->nama,
                "harga" => $request->harga,
                "foto_produk" => $request->foto_produk,
                "deskripsi" => $request->deskripsi,
            ]);

            return response()->json([
                "message" => "Data produk berhasil ditambahkan",
                "data" => $produk
            ], Response::HTTP_CREATED);

        } catch (\Throwable $th) {
            return response()->json([
                "message" => "Data produk gagal ditambahkan",
                "error" => $th->getMessage(),
            ], Response::HTTP_BAD_REQUEST);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        try {
            $produk = Produk::with('kategori')->findOrFail($id);
            return response()->json([
                'message' => 'Data produk berhasil diambil',
                'data' => $produk,
            ], Response::HTTP_OK);

        } catch (\Throwable $th) {
            return response()->json([
                'message' => 'Produk tidak ditemukan',
                'error' => $th->getMessage(),
            ], Response::HTTP_NOT_FOUND);
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        try {
            $request->validate([
                "nama" => ["required"],
                "harga" => ["required", "numeric"],
                "deskripsi" => ["nullable"]
            ], [
                "nama.required" => "Nama produk harus diisi",
                "harga.required" => "Harga produk harus diisi",
                "harga.numeric" => "Harga produk harus berupa angka"
            ]);

            $produk = Produk::find($id);
            if (!$produk) {
                return response()->json([
                    "message" => "Data produk tidak ditemukan"
                ], Response::HTTP_NOT_FOUND);
            }

            $produk->update([
                "nama" => $request->nama,
                "harga" => $request->harga,
                "deskripsi" => $request->deskripsi
            ]);

            return response()->json([
                "message" => "Data produk berhasil diubah",
                "data" => $produk
            ], Response::HTTP_OK);

        } catch (\Throwable $th) {
            return response()->json([
                "message" => "Data produk gagal diubah",
                "error" => $th->getMessage(),
            ], Response::HTTP_BAD_REQUEST);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        try {
            $produk = Produk::find($id);

            if (!$produk) {
                return response()->json([
                    "message" => "Data produk tidak ditemukan"
                ], Response::HTTP_NOT_FOUND);
            }

            $produk->delete();

            return response()->json([
                "message" => "Data produk berhasil dihapus"
            ], Response::HTTP_OK);

        } catch (\Throwable $th) {
            return response()->json([
                "message" => "Data produk gagal dihapus",
                "error" => $th->getMessage(),
            ], Response::HTTP_BAD_REQUEST);
        }
    }

    public function getProdukDenganKategori()
    {
        $produk = Produk::join('kategori', 'produk.kategori_id', '=', 'kategori.id')
            ->select('produk.id', 'kategori.nama as kategori', 'produk.nama', 'produk.deskripsi', 'produk.harga')
            ->get();

        return response()->json($produk);
    }

    public function getProdukDenganJumlahTransaksi()
    {
        $produk = Produk::withCount('transaksi')
            ->with('kategori')
            ->get(['id', 'nama', 'harga', 'kategori_id']);

        return response()->json($produk);
    }

}
