<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Pelanggan;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class PelangganController extends Controller
{
    public function index(Request $request)
    {
        $pelanggan = Pelanggan::all();
        $data = [
            "message" => "Data pelanggan berhasil diambil",
            "data" => $pelanggan,
        ];
        return response()->json($data, Response::HTTP_OK);
    }

    public function store(Request $request)
    {
        try {
            // Validasi input
            $request->validate([
                "nama_lengkap" => ["required"],
                "email" => ["required", "email"],
                "nomor_hp" => ["required"],
            ], [
                "nama_lengkap.required" => "Nama lengkap harus diisi",
                "email.required" => "Email harus diisi",
                "email.email" => "Format email tidak valid",
                "nomor_hp.required" => "Nomor HP harus diisi",
            ]);

            // Simpan data pelanggan
            Pelanggan::create($request->all());

            return response()->json([
                "message" => "Data pelanggan berhasil ditambahkan",
            ], Response::HTTP_CREATED);
        } catch (\Throwable $th) {
            return response()->json([
                "message" => "Data pelanggan gagal ditambahkan",
                "error" => $th->getMessage(),
            ], Response::HTTP_BAD_REQUEST);
        }
    }

    public function show($id)
    {
        try {
            $pelanggan = Pelanggan::findOrFail($id);
            return response()->json([
                'message' => 'Data pelanggan berhasil diambil',
                'data' => $pelanggan,
            ], Response::HTTP_OK);
        } catch (\Throwable $th) {
            return response()->json([
                "message" => "Data pelanggan tidak ditemukan",
                "error" => $th->getMessage(),
            ], Response::HTTP_NOT_FOUND);
        }
    }

    public function update(Request $request, $id)
    {
        try {
            // Validasi input
            $request->validate([
                "nama_lengkap" => ["required"],
                "email" => ["required", "email"],
                "nomor_hp" => ["required"],
            ]);

            // Temukan pelanggan berdasarkan ID
            $pelanggan = Pelanggan::findOrFail($id);
            $pelanggan->update($request->all());

            return response()->json([
                "message" => "Data pelanggan berhasil diperbarui",
            ], Response::HTTP_OK);
        } catch (\Throwable $th) {
            return response()->json([
                "message" => "Data pelanggan gagal diperbarui",
                "error" => $th->getMessage(),
            ], Response::HTTP_BAD_REQUEST);
        }
    }

    public function destroy($id)
    {
        try {
            $pelanggan = Pelanggan::findOrFail($id);
            $pelanggan->delete();

            return response()->json([
                "message" => "Data pelanggan berhasil dihapus",
            ], Response::HTTP_OK);
        } catch (\Throwable $th) {
            return response()->json([
                "message" => "Data pelanggan gagal dihapus",
                "error" => $th->getMessage(),
            ], Response::HTTP_BAD_REQUEST);
        }
    }

    public function getPelangganDenganJumlahTransaksi()
    {
        $pelanggan = Pelanggan::withCount('transaksi')
            ->get(['id', 'nama', 'nomor_telepon', 'alamat']);

        return response()->json($pelanggan);
    }
}
