<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class UserController extends Controller
{
    public function saveAddress(Request $request)
    {
        // Validasi input
        $request->validate([
            'recipient_name' => 'required|string',
            'recipient_phone' => 'required|string',
            'address' => 'required|string',
            'city_name' => 'required|string',
            'province_name' => 'required|string',
        ]);

        // Pastikan user terautentikasi
        $user = auth()->user();
        if (!$user) {
            return response()->json(['error' => 'User tidak terautentikasi'], 401);
        }

        // Ambil data provinsi dan kota
        $provinceName = $request->province_name;
        $cityName = $request->city_name;

        // Cari ID Kota
        $cityId = $this->getCityId($provinceName, $cityName);

        if (!$cityId) {
            return response()->json(['error' => 'Kota tidak ditemukan'], 404);
        }

        // Cari ID Provinsi
        $provinceId = $this->getProvinceId($provinceName);
        if (!$provinceId) {
            return response()->json(['error' => 'Provinsi tidak ditemukan'], 404);
        }

        // Gabungkan detail alamat, termasuk city_id dan province_id
        $fullAddress = sprintf(
            "Nama Penerima: %s, No. Telepon: %s, Alamat: %s, Kota: %s, Provinsi: %s, City ID: %s, Province ID: %s",
            $request->recipient_name,
            $request->recipient_phone,
            $request->address,
            $cityName,
            $provinceName,
            $cityId, // Menyertakan city_id
            $provinceId // Menyertakan province_id
        );

        // Simpan alamat (termasuk city_id dan province_id) ke database
        $user->address = $fullAddress; // Simpan dalam kolom address
        $user->save();

        return response()->json([
            'success' => true,
            'address' => $user->address,
            'city_id' => $cityId, // Mengembalikan city_id
            'province_id' => $provinceId, // Mengembalikan province_id
        ]);
    }


    /**
     * Fungsi untuk mendapatkan ID kota berdasarkan nama provinsi dan kota.
     */
    private function getCityId($provinceName, $cityName)
    {
        // Ambil ID provinsi berdasarkan nama
        $provinceId = $this->getProvinceId($provinceName);

        if (!$provinceId) {
            return null; // Jika provinsi tidak ditemukan
        }

        // Ambil daftar kota berdasarkan ID provinsi
        $response = Http::withHeaders([
            'key' => '35b96dafde2144bad5afa81a64e8d8a9', // Ganti dengan API Key RajaOngkir Anda
        ])->get('https://api.rajaongkir.com/starter/city', [
                    'province' => $provinceId, // Gunakan ID provinsi
                ]);

        if ($response->successful()) {
            $cities = $response->json()['rajaongkir']['results'];
            foreach ($cities as $city) {
                if (strtolower($city['city_name']) == strtolower($cityName)) {
                    return $city['city_id'];
                }
            }
        }

        return null; // Jika kota tidak ditemukan
    }

    /**
     * Fungsi untuk mendapatkan ID provinsi berdasarkan nama provinsi.
     */
    private function getProvinceId($provinceName)
    {
        $response = Http::withHeaders([
            'key' => '35b96dafde2144bad5afa81a64e8d8a9', // Ganti dengan API Key RajaOngkir Anda
        ])->get('https://api.rajaongkir.com/starter/province');

        if ($response->successful()) {
            $provinces = $response->json()['rajaongkir']['results'];
            foreach ($provinces as $province) {
                if (strtolower($province['province']) == strtolower($provinceName)) {
                    return $province['province_id'];
                }
            }
        }

        return null; // Jika provinsi tidak ditemukan
    }

    public function deleteAddress(Request $request)
    {
        $user = auth()->user();

        if ($user->address) {
            $user->address = null; // Hapus alamat
            $user->save();

            return response()->json(['success' => true, 'message' => 'Alamat berhasil dihapus.']);
        }

        return response()->json(['success' => false, 'message' => 'Alamat tidak ditemukan.']);
    }

}
