<?php

namespace App\Http\Controllers;

use App\Models\Transaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;

class TransactionController extends Controller
{
    // Endpoint untuk menangani notifikasi pembayaran dari Midtrans
    public function handleMidtransNotification(Request $request)
    {
        // Ambil data dari notifikasi Midtrans
        $transaction = $request->all();

        // Cek jika data penting ada dalam request
        if (!isset($transaction['transaction_status']) || !isset($transaction['order_id'])) {
            Log::error('Invalid notification received', $transaction);
            return response()->json(['message' => 'Invalid notification data'], 400);
        }

        // Cek status transaksi
        $status = $transaction['transaction_status'];
        $order_id = $transaction['order_id'];
        $payment_type = $transaction['payment_type'];
        $payment_method = $transaction['payment_method'] ?? null;
        $gross_amount = $transaction['gross_amount'];
        $courier = isset($transaction['courier']) ? strtoupper($transaction['courier']) : null;  // Ubah menjadi huruf besar
        $courier_service = $transaction['service'] ?? null; // Menggunakan null jika service tidak ada
        $customer_name = $transaction['customer_name'] ?? 'Unknown';

        // Cari user berdasarkan order_id, atau order_id bisa mengacu ke user yang terkait
        // Misalnya, jika order_id ada di tabel users, kita dapat mencari user melalui order_id
        $user = Auth::user(); // Pastikan user sudah login

        if (!$user) {
            Log::error('User not found for transaction', ['order_id' => $order_id]);
            return response()->json(['message' => 'User not found'], 404);
        }

        // Simpan data transaksi ke dalam tabel transactions
        $transactionRecord = new Transaction();
        $transactionRecord->order_id = $order_id;
        $transactionRecord->user_id = $user->id;  // Pastikan user sudah login
        $transactionRecord->customer_name = $customer_name;
        $transactionRecord->gross_amount = $gross_amount;
        $transactionRecord->payment_type = $payment_type;
        $transactionRecord->payment_method = $payment_method;
        $transactionRecord->courier = $courier; // Ubah menjadi huruf besar jika perlu
        $transactionRecord->courier_service = $courier_service;
        $transactionRecord->transaction_status = $status;
        $transactionRecord->transaction_time = now(); // Waktu transaksi
        $transactionRecord->save();

        // Verifikasi dan update status transaksi
        if ($status === 'settlement') {
            // Jika status transaksi adalah "settlement", ubah status menjadi sukses
            $transactionRecord->transaction_status = 'success';
            $transactionRecord->save();
        } elseif ($status === 'expired' || $status === 'failed') {
            // Jika status transaksi adalah "expired" atau "failed", ubah status menjadi gagal
            $transactionRecord->transaction_status = 'failed';
            $transactionRecord->save();
        }

        // Kirimkan status ke Midtrans setelah memproses notifikasi
        return response()->json(['message' => 'Transaction processed successfully.'], 200);
    }
}
