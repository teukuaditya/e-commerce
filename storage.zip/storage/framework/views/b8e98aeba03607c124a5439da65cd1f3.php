<?php $__env->startSection('content'); ?>
    <!-- breadcrumb -->
    <div class="container">
        <div class="bread-crumb flex-w p-r-15 p-t-30 p-lr-0-lg">
            <a href="<?php echo e(route('user.categories.index')); ?>" class="stext-109 cl8 hov-cl1 trans-04">
                Category
                <i class="fa fa-angle-right m-l-9 m-r-10" aria-hidden="true"></i>
            </a>

            <span class="stext-109 cl4">
                Show Product
            </span>
        </div>
    </div>
    <div class="bg0 m-t-23 p-b-140">
        <div class="container">
            <div class="flex-w flex-sb-m p-b-52">
                <!-- Tombol Filter Kategori -->
                <div class="flex-w flex-l-m filter-tope-group m-tb-10">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('user.categories.products', $category->id)); ?>">
                            <button
                                class="stext-106 cl6 hov1 bor3 trans-04 m-r-32 m-tb-5
                            <?php echo e(request()->route('id') == $category->id ? 'how-active1' : ''); ?>">
                                <?php echo e($category->category_name); ?>

                            </button>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <!-- Tombol Filter dan Search -->
                <div class="flex-w flex-c-m m-tb-10">
                    <div class="flex-c-m stext-106 cl6 size-104 bor4 pointer hov-btn3 trans-04 m-r-8 m-tb-4 js-show-filter">
                        <i class="icon-filter cl2 m-r-6 fs-15 trans-04 zmdi zmdi-filter-list"></i>
                        <i class="icon-close-filter cl2 m-r-6 fs-15 trans-04 zmdi zmdi-close dis-none"></i>
                        Filter
                    </div>

                    <div class="flex-c-m stext-106 cl6 size-105 bor4 pointer hov-btn3 trans-04 m-tb-4 js-show-search">
                        <i class="icon-search cl2 m-r-6 fs-15 trans-04 zmdi zmdi-search"></i>
                        <i class="icon-close-search cl2 m-r-6 fs-15 trans-04 zmdi zmdi-close dis-none"></i>
                        Search
                    </div>
                </div>
            </div>

            <!-- Produk -->
            <div class="row isotope-grid">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div
                        class="col-sm-6 col-md-4 col-lg-3 p-b-35 isotope-item <?php echo e(strtolower($product->category->category_name)); ?>">
                        <!-- Block2 -->
                        <div class="block2">
                            <div class="block2-pic hov-img0">
                                <a href="<?php echo e(route('user.products.show', $product->id)); ?>">
                                    <img src="<?php echo e(asset('storage/products/' . (is_array($product->image) ? $product->image[0] : $product->image))); ?>"
                                        alt="<?php echo e($product->title); ?>">
                                </a>

                                <a href="<?php echo e(route('user.products.show', $product->id)); ?>"
                                    class="block2-btn flex-c-m stext-103 cl2 size-102 bg0 bor2 hov-btn1 p-lr-15 trans-04">
                                    Add To Cart
                                </a>
                            </div>

                            <div class="block2-txt flex-w flex-t p-t-14">
                                <div class="block2-txt-child1 flex-col-l">
                                    <a href="<?php echo e(route('user.products.show', $product->id)); ?>"
                                        class="stext-106 cl5 hov-cl1 trans-04" style="font-weight: bold;">
                                        <?php echo e($product->brand); ?>

                                    </a>

                                    <a href="<?php echo e(route('user.products.show', $product->id)); ?>"
                                        class="stext-104 cl4 hov-cl1 trans-04 js-name-b2 p-b-6">
                                        <?php echo e($product->title); ?>

                                    </a>

                                    <a href="<?php echo e(route('user.products.show', $product->id)); ?>"
                                        class="stext-105 cl3 hov-cl1 trans-04">
                                        Rp <?php echo e(number_format($product->price, 0, ',', '.')); ?>

                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TUGAS PRAKTIK\flexora\resources\views/user/categories/show.blade.php ENDPATH**/ ?>