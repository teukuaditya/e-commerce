<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h2>Checkout</h2>
        </div>
        <div class="card-body">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($error); ?><br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>

            <div class="alert alert-primary mb-4" role="alert">
                Kota Asal: Tangerang, Banten -> Kota Tujuan: Malang, Jawa Timur
            </div>
            <form action="<?php echo e(route('dashboard.checkout.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div id="product" class="row mb-4">
                    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3 mb-3">
                            <div class="card" style="width: 100%;">
                                <img src="<?php echo e(asset('storage/' . $item->foto_produk)); ?>" class="card-img-top"
                                    alt="Foto Produk">
                                <div class="card-body">
                                    <h5 class="card-title text-dark" style="font-size: 18px;">
                                        <strong><?php echo e($item->nama); ?></strong>
                                    </h5>
                                    <span class="badge badge-primary"
                                        style="color: white; margin-bottom: 10px; font-size: 12px"><?php echo e($item->kategori->nama); ?></span>
                                    <p class="card-text text-dark" style="font-size: 14px;"><?php echo e($item->deskripsi); ?></p>
                                    <p class="card-text text-dark" style="font-size: 16px;">
                                        <strong><?php echo e('Rp ' . number_format($item->harga, 0, ',', '.')); ?></strong>
                                    </p>
                                    <input type="hidden" name="product_price[]" value="<?php echo e($item->harga); ?>">
                                    <input type="hidden" name="product_id[]" value="<?php echo e($item->id); ?>">

                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <button type="button" class="btn btn-outline-secondary"
                                                onclick="updateQuantity(<?php echo e($item->id); ?>, -1)">-</button>
                                        </div>
                                        <input type="number" class="form-control text-center" name="product_quantity[]"
                                            id="product_quantity_<?php echo e($item->id); ?>" value="0">
                                        <div class="input-group-append">
                                            <button type="button" class="btn btn-outline-secondary"
                                                onclick="updateQuantity(<?php echo e($item->id); ?>, 1)">+</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div id="courier" class="mb-4">
                    <div class="row">
                        <div class="col-md-6">
                            <label for="courier_type">Courier</label>
                            <select class="form-control" name="courier_type" id="courier_type">
                                <option value="jne">JNE</option>
                                <option value="tiki">TIKI</option>
                                <option value="pos">POS</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="courier_service">Service</label>
                            <select class="form-control" name="courier_service" id="courier_service" disabled>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="card mb-4">
                    <div class="card-header">
                        Detail Transaksi
                    </div>
                    <div class="card-body">
                        <ul class="list-group list-group-flush" id="transaction_details">
                        </ul>
                    </div>
                    <div class="card-footer">
                        <div id="product_total" class="d-none">0</div>
                        <div class="d-flex justify-content-between">
                            <strong>Total</strong>
                            <strong>Rp. <span id="detail_total">0</span></strong>
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary" id="btnSubmit">Checkout</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        function updateQuantity(productId, delta) {
            let quantityInput = $(`#product_quantity_${productId}`);
            let currentQuantity = parseInt(quantityInput.val()) || 0;
            let newQuantity = Math.max(0, currentQuantity + delta);
            quantityInput.val(newQuantity);
            calculateTotal();
        }

        function calculateTotal() {
            let total = 0;
            let hasProducts = false; // Menandakan apakah ada produk dengan jumlah > 0
            $('[name="product_quantity[]"]').each(function(index, item) {
                let quantity = parseInt($(item).val()) || 0;
                if (quantity > 0) {
                    hasProducts = true;
                    let price = parseInt($('[name="product_price[]"]').eq(index).val());
                    total += price * quantity;
                    let productId = $('[name="product_id[]"]').eq(index).val();
                    $(`#transaction_details`).find(`li[data-id="${productId}"]`).show();
                    $(`#transaction_details`).find(`li[data-id="${productId}"] .quantity`).html(quantity);
                    $(`#transaction_details`).find(`li[data-id="${productId}"] .price`).html(price * quantity);
                } else {
                    let productId = $('[name="product_id[]"]').eq(index).val();
                    $(`#transaction_details`).find(`li[data-id="${productId}"]`).hide();
                }
            });

            // Menampilkan total jika ada produk yang dipilih
            if (hasProducts) {
                $('#product_total').html(total);
                $('#detail_total').html(total + parseInt($('#detail_ongkir').html() || 0));
            } else {
                $('#product_total').html(0);
                $('#detail_total').html(0);
            }
        }

        $(document).ready(function() {
            const products = <?php echo json_encode($product, 15, 512) ?>;

            products.forEach(product => {
                $('#transaction_details').append(
                    `<li class="list-group-item" data-id="${product.id}" style="display: none;">
                    <div class="d-flex justify-content-between">
                        <span>${product.nama} - ${product.deskripsi}</span>
                        <span>(<span class="quantity">0</span>) Rp. <span class="price">0</span></span>
                    </div>
                </li>`
                );
            });

            $('#transaction_details').append(
                `<li class="list-group-item">
                <div class="d-flex justify-content-between">
                    <span>Ongkir</span>
                    <span>Rp. <span id="detail_ongkir">0</span></span>
                </div>
            </li>`
            );

            $('#courier_type').change(initData);

            $('#courier_service').change(function() {
                let service = $(this).val();
                let split = service.split('-');
                let service_price = split[2];
                let product_total = $('#product_total').html();
                let total = parseInt(product_total) + parseInt(service_price);
                $('#detail_total').html(total);
                $('#detail_ongkir').html(service_price);
            });

            initData(); // Memanggil fungsi untuk menginisialisasi data

            $('[name="product_quantity[]"]').on('input', function() {
                calculateTotal();
            });
        });

        function initData() {
            let courier = $('#courier_type').val();
            let origin = 456; // Kode Kota Asal
            let destination = 256; // Kode Kota Tujuan
            let weight = '2000'; // Berat dalam gram
            $('#courier_service').attr('disabled', true);
            $.ajax({
                url: '<?php echo e(url('api/cost')); ?>',
                type: 'POST',
                data: {
                    origin: origin,
                    destination: destination,
                    weight: weight,
                    courier: courier
                },
                beforeSend: function() {
                    $('#courier_service').html('<option>Loading...</option>');
                    $('#btnSubmit').attr('disabled', true);
                },
                success: function(result) {
                    $('#btnSubmit').attr('disabled', false);
                    let results = result.rajaongkir.results;
                    $('#courier_service').html('');
                    results.forEach(result => {
                        result.costs.forEach(cost => {
                            $('#courier_service').append(
                                `<option value="${cost.service}-${cost.description}-${cost.cost[0].value}">
                                ${cost.service} - ${cost.description} - Rp. ${cost.cost[0].value}
                            </option>`
                            );
                        });
                    });
                    $('#courier_service').attr('disabled', false);

                    // Mendapatkan ongkir dari layanan pertama dan mengupdate detail ongkir
                    let firstService = $('#courier_service').find('option:first').val();
                    if (firstService) {
                        let split = firstService.split('-');
                        let service_price = split[2];
                        $('#detail_ongkir').html(service_price);
                        calculateTotal();
                    }
                }
            });
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TUGAS PRAKTIK\e-commerce\resources\views/pages/checkout/index.blade.php ENDPATH**/ ?>