<?php $__env->startSection('content'); ?>
    <h1 class="h1 mb-4 text-dark">Pelanggan</h1>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <a href="<?php echo e(route('dashboard.pelanggan.create')); ?>" class="btn btn-primary mb-3">Tambah Pelanggan</a>

    <div class="row">
        <?php $__currentLoopData = $pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mb-4">
                <div class="card h-100">
                    <div class="card-body">
                        <p class="card-title"><strong>Nama:</strong> <?php echo e($p->nama_lengkap); ?></p>
                        <p class="card-text"><strong>Jenis Kelamin:</strong>
                            <?php echo e($p->jenis_kelamin == 'L' ? 'Laki-laki' : 'Perempuan'); ?></p>
                        <p class="card-text"><strong>Email:</strong> <?php echo e($p->email); ?></p>
                        <p class="card-text"><strong>Nomor HP:</strong> <?php echo e($p->nomor_hp); ?></p>
                        <p class="card-text"><strong>Alamat:</strong> <?php echo e($p->alamat); ?></p>
                        <div class="text-center">
                            <?php if($p->foto_profil): ?>
                                <img src="<?php echo e(asset('storage/' . $p->foto_profil)); ?>" class="img-fluid" alt="Foto Profil"
                                    style="max-height: 150px;">
                            <?php else: ?>
                                <p>Tidak ada foto</p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="card-footer text-center">
                        <a href="<?php echo e(route('dashboard.pelanggan.edit', $p->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                        <form action="<?php echo e(route('dashboard.pelanggan.destroy', $p->id)); ?>" method="POST"
                            style="display: inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm"
                                onclick="return confirm('Yakin ingin menghapus pelanggan ini?')">Hapus</button>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TUGAS PRAKTIK\e-commerce\resources\views/pages/pelanggan/pelanggan.blade.php ENDPATH**/ ?>