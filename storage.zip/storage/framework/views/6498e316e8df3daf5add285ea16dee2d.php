<?php $__env->startSection('content'); ?>
    <!-- breadcrumb -->
    <div class="container">
        <div class="bread-crumb flex-w p-r-15 p-t-30 p-lr-0-lg">
            <a href="<?php echo e(route('user.cart.index')); ?>" class="stext-109 cl8 hov-cl1 trans-04">
                Cart
                <i class="fa fa-angle-right m-l-9 m-r-10" aria-hidden="true"></i>
            </a>

            <span class="stext-109 cl4">
                Checkout
            </span>
        </div>
    </div>
    <section class="bg0 m-t-45 p-b-60">
        <div class="container">
            <div class="row">
                <!-- Kolom Kiri: Alamat dan Shipping -->
                <div class="col-lg-7">
                    <div class="bor10 p-lr-40 p-t-30 p-b-30 m-lr-0-xl p-lr-15-sm">
                        <h3 class="mtext-109 cl2 p-b-30">Delivery</h3>
                        <form action="#" id="address-form">
                            <!-- Alamat Pengiriman -->
                            <div class="size-204 respon6-next">

                                <!-- Menampilkan Alamat yang Tersimpan -->
                                <?php if(auth()->user()->address): ?>
                                    <?php
                                        // Mengurai data alamat berdasarkan label dan bagian penting
                                        $address = auth()->user()->address;

                                        // Memisahkan setiap bagian menggunakan koma tetapi kita pastikan hanya bagian yang benar
                                        preg_match(
                                            '/Nama Penerima: (.*?), No. Telepon: (.*?), Alamat: (.*?), Kota: (.*?), Provinsi: (.*?), City ID: (.*?)/',
                                            $address,
                                            $matches,
                                        );

                                        // Menyimpan data yang ditemukan dari regex
                                        $recipientName = $matches[1] ?? '';
                                        $recipientPhone = $matches[2] ?? '';
                                        $streetAddress = $matches[3] ?? '';
                                        $city = $matches[4] ?? '';
                                        $province = $matches[5] ?? '';
                                    ?>
                                    <div class="d-flex flex-column align-items-start">
                                        <!-- Nama Penerima -->
                                        <h6 class="mtext-106 cl2 mb-1" style="font-weight: bold; font-size: 16px;">
                                            <?php echo e($recipientName); ?></h6>

                                        <!-- Nomor Telepon -->
                                        <p class="stext-101 cl2 mb-1" style="font-size: 14px;"><?php echo e($recipientPhone); ?></p>

                                        <!-- Alamat -->
                                        <p class="stext-104 cl2 mb-1"><?php echo e($streetAddress); ?></p>

                                        <!-- Provinsi dan Kota -->
                                        <p class="stext-102 cl3"><?php echo e($province); ?>, <?php echo e($city); ?></p>
                                    </div>
                                <?php else: ?>
                                    <div class="stext-102 cl2">
                                        <p id="no-address-text">No address available. Please add a new address.</p>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <!-- Tombol Hapus Alamat -->
                            <button type="button" id="delete-address-btn"
                                class="flex-c-m stext-103 cl0 size-126 bg10 mt-3 bor14 hov-btn4 p-lr-15 trans-04 pointer">
                                Delete Address
                            </button>

                            <!-- Tampilkan tombol untuk menambah alamat jika belum ada -->
                            <?php if(!auth()->user()->address): ?>
                                <button type="button" id="add-address-btn"
                                    class="flex-c-m stext-103 cl0 size-126 bg3 mt-3 bor14 hov-btn3 p-lr-15 trans-04 pointer"
                                    data-toggle="modal" data-target="#addAddressModal">
                                    Add Address
                                </button>
                            <?php endif; ?>

                            <!-- Modal -->
                            <div class="modal fade" id="addAddressModal" tabindex="-1" role="dialog"
                                aria-labelledby="addAddressModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title mtext-103 cl2" id="addAddressModalLabel">Add Address</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body stext-102 cl2">
                                            <form id="new-address-form">
                                                <div class="form-group">
                                                    <label for="recipient-name">Recipient Name</label>
                                                    <input type="text" class="form-control" id="recipient-name">
                                                </div>
                                                <div class="form-group">
                                                    <label for="recipient-phone">Phone Number</label>
                                                    <input type="text" class="form-control" id="recipient-phone">
                                                </div>
                                                <div class="form-group">
                                                    <label for="new-address">Full Address</label>
                                                    <textarea class="form-control" id="new-address" rows="2"></textarea>
                                                </div>
                                                <div class="form-group">
                                                    <label for="new-province">Province</label>
                                                    <select id="new-province" class="form-control">
                                                        <option value="">Select Province</option>
                                                        <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($province['province_id']); ?>">
                                                                <?php echo e($province['province']); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div class="form-group">
                                                    <label for="new-city">City</label>
                                                    <select id="new-city" class="form-control" disabled>
                                                        <option value="">Select City</option>
                                                    </select>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button"
                                                class="flex-c-m stext-102 cl0 size-304 bg10 bor14 hov-btn4 p-lr-15 trans-04 pointer"
                                                data-dismiss="modal">Cancel</button>
                                            <button type="button" id="save-address-btn"
                                                class="flex-c-m stext-102 cl0 size-304 bg1 bor14 hov-btn5 p-lr-15 trans-04 pointer">Save
                                                Address</button>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <!-- Style untuk menonaktifkan tombol -->
                            <style>
                                /* Mengubah tombol saat dinonaktifkan */
                                #save-address-btn:disabled {
                                    opacity: 0.5;
                                    /* Membuat tombol tampak lebih transparan */
                                    cursor: not-allowed;
                                    /* Menonaktifkan pointer */
                                    pointer-events: none;
                                    /* Tidak bisa diklik */
                                }

                                /* Menimpa efek hover dan pointer saat tombol sedang dalam status "Menyimpan..." */
                                #save-address-btn.saving {
                                    opacity: 0.5;
                                    /* Membuat tombol tampak transparan */
                                    cursor: not-allowed;
                                    /* Menonaktifkan pointer */
                                    pointer-events: none;
                                    /* Tidak bisa diklik */
                                    background-color: #dcdcdc;
                                    /* Ganti warna latar belakang saat sedang menyimpan */
                                }

                                /* Menimpa hover saat tombol sedang menyimpan */
                                #save-address-btn.saving:hover {
                                    background-color: #f0f0f0;
                                    /* Menjaga warna latar belakang */
                                }
                            </style>

                            <style>
                                /* CSS untuk Modal */
                                .modal-backdrop {
                                    z-index: 1200 !important;
                                    /* Pastikan backdrop lebih tinggi dari top bar */
                                }

                                .modal {
                                    z-index: 1300 !important;
                                    /* Modal harus berada di atas backdrop */
                                }

                                /* Memberikan margin atas pada modal */
                                .modal-dialog {
                                    margin-top: 80px;
                                    /* Atur sesuai dengan kebutuhan, semakin besar maka semakin ke bawah */
                                }
                            </style>
                    </div>

                    <!-- Shipping Method -->
                    <div class="bor10 p-lr-40 p-t-30 p-b-30 m-lr-0-xl p-lr-15-sm m-t-30">
                        <h3 class="mtext-109 cl2 p-b-30">Shipping Method</h3>
                        <div class="size-204 respon6-next">
                            <label for="courier" class="stext-102 cl2">Courier</label>
                            <div class="rs1-select2 bor8 bg0">
                                <select class="js-select2 form-control" id="courier">
                                    <option value="">Select Courier</option>
                                    <option value="jne">JNE</option>
                                    <option value="tiki">TIKI</option>
                                    <option value="pos">POS Indonesia</option>
                                </select>
                                <div class="dropDownSelect2"></div>
                            </div>
                        </div>

                        <!-- Dropdown untuk memilih layanan pengiriman berdasarkan kurir -->
                        <div class="size-204 respon6-next mt-3">
                            <label for="shipping-service" class="stext-102 cl2">Shipping Service</label>
                            <div class="rs1-select2 bor8 bg0">
                                <select class="js-select2 form-control" id="shipping-service" disabled>
                                    <option value="">Select Service</option>
                                </select>
                                <div class="dropDownSelect2"></div>
                            </div>
                        </div>
                        </form>
                    </div>
                </div>

                <!-- Kolom Kanan: Your Order dan Order Summary -->
                <div class="col-lg-5">
                    <div class="bor10 p-lr-40 p-t-30 p-b-30 m-lr-0-xl p-lr-15-sm">
                        <h4 class="mtext-109 cl2 p-b-30">Your Order</h4>
                        <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div
                                class="checkout-item d-flex align-items-center justify-content-between mb-4 p-3 shadow-sm rounded">
                                <div class="checkout-item-img" style="flex-shrink: 0; margin-right: 10px;">
                                    <img src="<?php echo e(asset('storage/products/' . $item->product->image[0])); ?>"
                                        alt="<?php echo e($item->product->title); ?>" class="rounded" width="100">
                                </div>
                                <div class="checkout-item-info flex-grow-1"
                                    style="flex-grow: 1; margin-left: 20px; display: flex; flex-direction: column;">
                                    <h6 class="stext-102 cl2" style="font-weight: bold; font-size: 15px;">
                                        <?php echo e($item->product->brand); ?>

                                    </h6>
                                    <p class="stext-102 cl2 mb-1"><?php echo e($item->product->title); ?></p>
                                    <span class="mtext-107 cl2" style="font-size: 15px; font-weight: bold;">
                                        Rp <?php echo e(number_format($item->product->price, 0, ',', '.')); ?>

                                    </span>
                                    <p class="stext-102 cl2 mb-1" style="font-size: 12px;">
                                        Variant: <?php echo e($item->size ?? 'No Size'); ?>

                                    </p>
                                    <p class="stext-102 cl2" style="font-size: 12px;">
                                        x <?php echo e($item->quantity); ?>

                                    </p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="bor10 p-lr-40 p-t-30 p-b-30 m-lr-0-xl p-lr-15-sm m-t-30">
                        <div class="order-summary">
                            <h4 class="mtext-109 cl2 p-b-30">Order Summary</h4>
                            <div class="d-flex justify-content-between bor12 p-b-13 mb-3">
                                <span class="stext-110 cl2">Subtotal:</span>
                                <span class="mtext-107 cl2" id="cart-subtotal">Rp 0</span> <!-- Inisialisasi Subtotal -->
                            </div>

                            <div class="d-flex justify-content-between bor12 p-b-13 mb-3">
                                <span class="stext-110 cl2">Shipping:</span>
                                <span id="shipping-fee" class="mtext-107 cl2">Rp 0</span>
                            </div>

                            <div class="d-flex justify-content-between p-t-27 p-b-33">
                                <span class="mtext-101 cl2"><strong>Total:</strong></span>
                                <span class="mtext-110 cl2"><strong id="total-amount">Rp 0</strong></span>
                                <!-- Inisialisasi Total -->
                            </div>
                        </div>
                        <a href="#" id="checkout-btn"
                            class="flex-c-m stext-101 cl0 size-116 bg3 bor14 hov-btn3 p-lr-15 trans-04 pointer">
                            Checkout
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            const origin = 153; // ID Kota Jakarta
            const userCityId = <?php echo json_encode($cityId ?? '', 15, 512) ?>; // ID Kota pengguna
            let totalWeight = 0;

            // Menghitung total berat produk dalam keranjang
            <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                totalWeight += <?php echo e($item->product->weight); ?> * <?php echo e($item->quantity); ?>;
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            // Memuat Kota Berdasarkan Provinsi
            $('#new-province').on('change', function() {
                const provinceId = $(this).val();
                if (provinceId) {
                    $.ajax({
                        url: `/api/cities/${provinceId}`, // Tambahkan "api/" sesuai dengan rute Anda
                        type: 'GET',
                        success: function(data) {
                            let cityOptions = '<option value="">Select City</option>';
                            $.each(data.rajaongkir.results, function(index, city) {
                                cityOptions +=
                                    `<option value="${city.city_id}">${city.city_name}</option>`;
                            });
                            $('#new-city').html(cityOptions);
                            $('#new-city').prop('disabled', false);
                        },
                        error: function(xhr) {
                            console.error(xhr.responseText); // Debugging
                            alert('Failed to load city data.');
                        }
                    });
                } else {
                    $('#new-city').html('<option value="">Select City</option>');
                    $('#new-city').prop('disabled', true);
                }
            });

            // Simpan alamat baru
            $('#save-address-btn').on('click', function() {
                const name = $('#recipient-name').val();
                const phone = $('#recipient-phone').val();
                const address = $('#new-address').val();
                const provinceName = $('#new-province option:selected').text(); // Nama provinsi
                const cityName = $('#new-city option:selected').text(); // Nama kota
                const cityId = $('#new-city').val(); // ID Kota yang terpilih

                if (name && phone && address && provinceName && cityName && cityId) {
                    $('#save-address-btn').html('Saving...').attr('disabled',
                        true); // Mengubah teks tombol dan menonaktifkan tombol
                    $.ajax({
                        url: '/save-address',
                        type: 'POST',
                        data: {
                            _token: '<?php echo e(csrf_token()); ?>',
                            recipient_name: name,
                            recipient_phone: phone,
                            address: address,
                            province_name: provinceName,
                            city_name: cityName
                        },
                        xhrFields: {
                            withCredentials: true // Kirimkan cookie sesi
                        },
                        success: function(response) {
                            if (response.success) {
                                location.reload();
                            } else {
                                alert('An error occurred. Please try again.');
                                resetButtonState(); // Reset tombol jika terjadi kesalahan
                            }
                        },
                        error: function(xhr) {
                            console.error(xhr.responseText);
                            alert('An error occurred. Please ensure all fields are correct.');
                            resetButtonState(); // Reset tombol jika terjadi kesalahan
                        }
                    });
                } else {
                    alert('Please make sure all fields are filled.');
                }
            });

            // Fungsi untuk mereset status tombol dan indikator loading
            function resetButtonState() {
                $('#save-address-btn').html('Save Address')
                    .removeClass('saving') // Menghapus kelas 'saving'
                    .prop('disabled', false); // Mengaktifkan tombol kembali
            }

            // Event listener untuk memilih kurir
            $('#courier').on('change', function() {
                const courier = $(this).val();

                if (courier && userCityId) {
                    // Tampilkan opsi "Loading..." sebelum AJAX call
                    $('#shipping-service').html('<option value="">Loading...</option>').prop('disabled',
                        true);

                    // AJAX call untuk mengambil data ongkir dari API
                    $.ajax({
                        url: `/api/cost`, // Pastikan URL ini sesuai dengan rute API Anda
                        type: 'POST',
                        data: {
                            origin: origin,
                            destination: userCityId,
                            weight: totalWeight,
                            courier: courier
                        },
                        success: function(data) {
                            // Menyiapkan opsi layanan pengiriman
                            let servicesOptions = '<option value="">Select Service</option>';
                            // Pastikan data yang diterima sesuai dengan format yang diinginkan
                            if (data.services && data.services.length > 0) {
                                data.services.forEach(function(service) {
                                    servicesOptions +=
                                        `<option value="${service.service}" data-cost="${service.cost}">${service.service} - Rp ${service.cost} - Estimated ${service.etd} Days</option>`;
                                });
                            } else {
                                servicesOptions +=
                                    '<option value="">No shipping services available</option>';
                            }

                            $('#shipping-service').html(servicesOptions).prop('disabled',
                                false);
                        },
                        error: function(xhr, status, error) {
                            console.error('AJAX Error:', status, error);
                        }
                    });
                }
            });

            // Hapus alamat yang tersimpan
            $('#delete-address-btn').on('click', function() {
                if (confirm('Are you sure you want to delete this address?')) {
                    $.ajax({
                        url: '/delete-address',
                        type: 'DELETE',
                        data: {
                            _token: '<?php echo e(csrf_token()); ?>'
                        },
                        success: function(response) {
                            if (response.success) {
                                alert('Address successfully deleted.');
                                location.reload(); // Refresh the page after deleting address
                            } else {
                                alert('An error occurred while deleting the address.');
                            }
                        },
                        error: function(xhr) {
                            console.error(xhr.responseText);
                            alert('Failed to delete address. Please try again.');
                        }
                    });
                }
            });
        });
        $(document).ready(function() {
            // Mengambil nilai subtotal dari backend
            let cartTotal = parseFloat("<?php echo e($cartTotal); ?>".replace(/\./g, '').replace(',', '.'));

            // Inisialisasi Subtotal
            $('#cart-subtotal').text(formatCurrency(cartTotal));

            // Fungsi untuk menghitung dan memperbarui total
            function updateTotal(shippingCost) {
                let total = cartTotal; // Mulai dengan subtotal

                // Jika ada biaya pengiriman yang lebih dari 0, tambahkan ke total
                if (shippingCost > 0) {
                    total += shippingCost;
                }

                // Menampilkan total dengan format yang benar
                $('#total-amount').text(formatCurrency(total));
            }

            // Fungsi untuk format mata uang
            function formatCurrency(amount) {
                return "Rp " + amount.toLocaleString('id-ID');
            }

            // Ketika memilih layanan pengiriman
            $('#shipping-service').on('change', function() {
                const selectedOption = $(this).find('option:selected');
                let shippingCost = selectedOption.data('cost'); // Ambil data-cost

                // Jika ada biaya pengiriman
                if (shippingCost) {
                    shippingCost = parseFloat(shippingCost.replace(/\./g, '').replace(',',
                        '.'));
                    $('#shipping-fee').text(formatCurrency(shippingCost));

                    // Update total dengan biaya pengiriman
                    updateTotal(shippingCost);
                } else {
                    // Jika biaya pengiriman adalah Rp 0
                    $('#shipping-fee').text("Rp 0");
                    // Update total hanya dengan subtotal (tanpa biaya pengiriman)
                    updateTotal(0); // Pengiriman Rp 0, total tetap dari subtotal
                }
            });

            // Jika pengiriman sudah di-set ke Rp 0, pastikan total tetap sesuai subtotal
            if ($('#shipping-fee').text() === 'Rp 0') {
                updateTotal(0); // Pengiriman Rp 0, hanya subtotal yang dihitung
            }
        });
        $(document).ready(function() {
            // Cek jika user sudah menambahkan alamat
            if (!<?php echo e(auth()->user()->address ? 'true' : 'false'); ?>) {
                $('#courier').prop('disabled', true); // Disable select if address is not added
            }

            // Misalnya, jika alamat sudah ditambahkan, enable select
            // Ini bisa terjadi setelah proses AJAX atau halaman di-refresh
            $('#add-address-btn').on('click', function() {
                // Jika user menambahkan alamat, enable select courier
                $('#courier').prop('disabled', false);
            });
        });

        // Ketika Klik Checkout
        $('#checkout-btn').on('click', function() {
            const orderId = "order-" + Math.random().toString(36).substr(2, 9); // ID Order unik
            const grossAmount = parseInt("<?php echo e($cartTotal); ?>".replace(/\./g, '').replace(',',
            '.')); // Total dari keranjang
            const customerDetails = {
                first_name: "<?php echo e(auth()->user()->name); ?>",
                email: "<?php echo e(auth()->user()->email); ?>",
                phone: "<?php echo e(auth()->user()->phone); ?>"
            };

            // Menyusun array items dari produk yang ada di keranjang
            let items = [];
            <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                items.push({
                    id: "<?php echo e($item->product->id); ?>",
                    product_brand: "<?php echo e($item->product->brand); ?>",
                    product_title: "<?php echo e($item->product->title); ?>",
                    product_size: "<?php echo e($item->size); ?>",
                    quantity: <?php echo e($item->quantity); ?>,
                    price: "<?php echo e($item->product->price); ?>",
                });
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            // Shipping details
            const selectedShippingOption = $('#shipping-service option:selected');
            let shippingCost = selectedShippingOption.data('cost');
            if (shippingCost) {
                shippingCost = parseFloat(shippingCost.replace(/\./g, '').replace(',', '.'));
            } else {
                shippingCost = 0;
            }

            const etd = selectedShippingOption.data('etd'); // Estimasi waktu pengiriman
            const courier = $('#courier').val().toUpperCase(); // Courier (e.g., JNE)
            const service = selectedShippingOption.val(); // Mendapatkan layanan (e.g., REG)

            if (!service || !shippingCost) {
                alert('Please select a shipping service.');
                return;
            }
            // Menambahkan biaya pengiriman ke total gross_amount
            const totalAmount = grossAmount + shippingCost; // Menambahkan biaya pengiriman

            // Data request untuk token Snap
            const requestData = {
                order_id: orderId,
                gross_amount: totalAmount, // Total yang sudah termasuk biaya pengiriman
                customer_details: customerDetails,
                shipping_cost: shippingCost, // Kirimkan biaya pengiriman ke backend
                courier: courier, // Kirimkan kurir
                service: service, // Kirimkan layanan pengiriman
                etd: etd, // Kirimkan estimasi waktu
                items: items, // Menambahkan items ke dalam request
                _token: '<?php echo e(csrf_token()); ?>'
            };

            console.log('Requesting Snap Token:', requestData);

            // Panggil API untuk mendapatkan Snap Token
            $.ajax({
                url: '/user/midtrans/snap',
                type: 'POST',
                data: requestData,
                success: function(response) {
                    if (response.token) {
                        console.log('Snap Token received:', response.token);

                        // Tampilkan popup pembayaran Snap
                        snap.pay(response.token, {
                            onSuccess: function(result) {
                                console.log('Payment success:', result);
                                alert('Payment successful!');

                                // Redirect ke halaman sukses atau simpan status pembayaran
                                window.location.href = "/checkout/success";
                            },
                            onPending: function(result) {
                                console.log('Payment pending:', result);
                                alert('Payment pending. Please complete the payment.');
                            },
                            onError: function(result) {
                                console.error('Payment error:', result);
                                alert('Payment failed. Please try again.');
                            },
                            onClose: function() {
                                alert('Payment popup closed. Transaction cancelled.');
                            }
                        });
                    } else {
                        alert('Failed to get Snap token. Please try again.');
                    }
                },
                error: function(xhr) {
                    console.error('Error:', xhr.responseText);
                    alert('Failed to connect to the server. Please try again.');
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TUGAS PRAKTIK\flexora\resources\views/user/checkout/index.blade.php ENDPATH**/ ?>