<?php $__env->startSection('content'); ?>
    <h1 class="h1 mb-4 text-dark">Kategori</h1>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <a href="<?php echo e(route('dashboard.kategori.create')); ?>" class="btn btn-primary mb-3">Tambah Kategori</a>
    <div class="row">
        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-2 mb-4">
                <div class="card w-100">
                    <div class="card-body">
                        <h5 class="card-title"><strong><?php echo e($kat->nama); ?></strong></h5>
                        <p class="card-text"><?php echo e($kat->keterangan); ?></p>
                    </div>
                    <div class="card-footer text-center">
                        <a href="<?php echo e(route('dashboard.kategori.edit', $kat->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                        <form action="<?php echo e(route('dashboard.kategori.destroy', $kat->id)); ?>" method="POST"
                            style="display:inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm"
                                onclick="return confirm('Yakin ingin menghapus kategori ini?')">Hapus</button>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TUGAS PRAKTIK\e-commerce\resources\views/pages/kategori/kategori.blade.php ENDPATH**/ ?>