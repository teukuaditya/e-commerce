<!-- Header -->
<header>
<!-- Header Mobile -->
<div class="wrap-header-mobile">
    <!-- Logo moblie -->
    <a href="<?php echo e(route('user.home')); ?>" class="logo-mobile">
        <span style="font-size: 25px; font-weight: bold; color: #000; letter-spacing: 2px;">FLEXORA</span>
    </a>

    <!-- Icon header -->
    <div class="wrap-icon-header flex-w flex-r-m m-r-15">
        <div class="icon-header-item cl2 hov-cl1 trans-04 p-r-11 js-show-modal-search">
            <i class="zmdi zmdi-search"></i>
        </div>

        <a href="<?php echo e(route('user.cart.index')); ?>">
            <div class="icon-header-item cl2 hov-cl1 trans-04 p-l-22 p-r-11 icon-header-noti js-show-cart"
                 data-notify="<?php echo e($cartCount); ?>">
                <i class="zmdi zmdi-shopping-cart"></i>
            </div>
        </a>

        <a href="#" class="dis-block icon-header-item cl2 hov-cl1 trans-04 p-r-11 p-l-10 icon-header-noti" data-notify="0">
            <i class="zmdi zmdi-favorite-outline"></i>
        </a>
    </div>

    <!-- Button show menu -->
    <div class="btn-show-menu-mobile hamburger hamburger--squeeze">
        <span class="hamburger-box">
            <span class="hamburger-inner"></span>
        </span>
    </div>
</div>


<!-- Menu Mobile -->
<div class="menu-mobile">

    <ul class="main-menu-m">
        <li class="<?php echo e(Route::currentRouteName() == 'user.home' ? 'active-menu' : ''); ?>">
            <a href="<?php echo e(route('user.home')); ?>">Home</a>
        </li>

        <li class="<?php echo e(Route::currentRouteName() == 'user.products.index' ? 'active-menu' : ''); ?>">
            <a href="<?php echo e(route('user.products.index')); ?>">Product</a>
        </li>

        <li class="<?php echo e(Route::currentRouteName() == 'user.categories.index' ? 'active-menu' : ''); ?>">
            <a href="<?php echo e(route('user.categories.index')); ?>">Category</a>
            <ul class="sub-menu">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e(route('user.categories.products', $category->id)); ?>"><?php echo e($category->category_name); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </li>

        <li class="<?php echo e(Route::currentRouteName() == 'blog' ? 'active-menu' : ''); ?>">
            <a href="">Blog</a>
        </li>

        <li class="<?php echo e(Route::currentRouteName() == 'about' ? 'active-menu' : ''); ?>">
            <a href="">About</a>
        </li>

        <li class="<?php echo e(Route::currentRouteName() == 'contact' ? 'active-menu' : ''); ?>">
            <a href="">Contact</a>
        </li>
    </ul>
</div>
</header>
<?php /**PATH D:\TUGAS PRAKTIK\flexora\resources\views/partials/mobile-nav.blade.php ENDPATH**/ ?>