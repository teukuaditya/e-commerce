<!-- Sidebar -->
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
        <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-laugh-wink"></i>
        </div>
        <div class="sidebar-brand-text mx-3">SB Admin <sup>2</sup></div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Product -->
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('dashboard.index')); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span></a>
    </li>

    <!-- Nav Item - Product -->
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('dashboard.kategori.index')); ?>">
            <i class="fas fa-fw fa-tags"></i>
            <span>Kategori</span></a>
    </li>

    <!-- Nav Item - Product -->
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('dashboard.produk.index')); ?>">
            <i class="fas fa-fw fa-box"></i>
            <span>Produk</span></a>
    </li>


    <!-- Nav Item - Product -->
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('dashboard.transaksi.index')); ?>">
            <i class="fas fa-fw fa-exchange-alt"></i>
            <span>Transaksi</span></a>
    </li>


    <!-- Nav Item - Product -->
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('dashboard.pelanggan.index')); ?>">
            <i class="fas fa-fw fa-users"></i>
            <span>Pelanggan</span></a>
    </li>

     <!-- Nav Item - Product -->
     <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('dashboard.cek-ongkir.index')); ?>">
            <i class="fas fa-fw fa-truck"></i>
            <span>Cek Ongkir</span></a>
    </li>

     <!-- Nav Item - Product -->
     <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('dashboard.checkout.index')); ?>">
            <i class="fas fa-shopping-cart"></i>
            <span>Checkout</span></a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider d-none d-md-block">

    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>

</ul>
<!-- End of Sidebar -->
<?php /**PATH D:\TUGAS PRAKTIK\e-commerce\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>