<?php $__env->startSection('content'); ?>

<div class="container-fluid d-flex justify-content-center align-items-center">
    <div class="card" style="width: 400px;">
        <div class="card-header text-center">
            <h4 class="mb-0">Login</h4>
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>

                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" name="email" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label for="password_confirmation" class="form-label">Ulang Password</label>
                    <input type="password" name="password_confirmation" class="form-control" required>
                </div>

                <?php if(Route::has('password.request')): ?>
                                <div class="text-center">
                                    <a class="small" href="<?php echo e(route('password.request')); ?>">Forgot Password?</a>
                                </div>
                                <?php endif; ?>

                <button type="submit" class="btn btn-primary btn-block mt-3">Login</button>
                <a href="<?php echo e(route('register')); ?>" class="btn btn-success btn-block mt-2">Register</a>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TUGAS PRAKTIK\e-commerce\resources\views/auth/login.blade.php ENDPATH**/ ?>