<?php $__env->startSection('content'); ?>
    <h1 class="h1 mb-4 text-dark">Produk</h1>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
    <a href="<?php echo e(route('dashboard.produk.create')); ?>" class="btn btn-primary mb-3">Tambah Produk</a>
    <div class="row">
        <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 mb-4">
                <div class="card h-100">
                    <?php if($item->foto_produk): ?>
                        <img src="<?php echo e(asset('storage/' . $item->foto_produk)); ?>" class="card-img-top" alt="Foto Produk">
                    <?php else: ?>
                        <div class="card-body text-center">
                            <p>Tidak ada foto</p>
                        </div>
                    <?php endif; ?>
                    <div class="card-body">
                        <span class="badge badge-primary"
                            style="color: white; margin-bottom: 10px; font-size: 12px"><?php echo e($item->kategori->nama); ?></span>
                        <h5 class="card-title text-dark" style="font-size: 18px;"><strong><?php echo e($item->nama); ?></strong></h5>
                        <p class="card-text text-dark" style="font-size: 14px;"><?php echo e($item->deskripsi); ?></p>
                        <p class="card-text text-dark" style="font-size: 16px;">
                            <strong><?php echo e('Rp ' . number_format($item->harga, 0, ',', '.')); ?></strong>
                        </p>
                        <div class="d-flex justify-content-start" style="margin-top: 10px">
                            <a href="<?php echo e(route('dashboard.produk.edit', $item->id)); ?>"
                                class="btn btn-warning btn-sm mr-2">Edit</a>
                            <form action="<?php echo e(route('dashboard.produk.destroy', $item->id)); ?>" method="POST"
                                style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm"
                                    onclick="return confirm('Yakin ingin menghapus produk ini?')">Hapus</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TUGAS PRAKTIK\e-commerce\resources\views/pages/produk/produk.blade.php ENDPATH**/ ?>