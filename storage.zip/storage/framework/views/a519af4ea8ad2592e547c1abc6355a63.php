<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Manage Categories</h2>

        <!-- Button to open the Create Category modal -->
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#categoryModal">
            Add Category
        </button>

        <!-- Success message -->
        <?php if(session('success')): ?>
            <div class="alert alert-success mt-3">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <!-- Table to list categories -->
        <table class="table table-bordered mt-4">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Category Name</th>
                    <th>Description</th>
                    <th>Image</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($category->id); ?></td>
                        <td><?php echo e($category->category_name); ?></td>
                        <td><?php echo e($category->description); ?></td>
                        <td>
                            <?php if($category->image): ?>
                            <img src="<?php echo e(asset('storage/categories/' . $category->image)); ?>" alt="<?php echo e($category->category_name); ?>" width="100">
                            <?php else: ?>
                                No image
                            <?php endif; ?>

                        </td>
                        <td>
                            <!-- Button to open the Edit modal -->
                            <button class="btn btn-warning btn-sm" data-toggle="modal" data-target="#categoryModal"
                                data-id="<?php echo e($category->id); ?>" data-category_name="<?php echo e($category->category_name); ?>"
                                data-description="<?php echo e($category->description); ?>" data-image="<?php echo e($category->image); ?>">
                                Edit
                            </button>

                            <!-- Button to delete category -->
                            <form action="<?php echo e(route('admin.categories.destroy', $category->id)); ?>" method="POST"
                                style="display:inline"
                                onsubmit="return confirm('Are you sure you want to delete this category?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <!-- Modal for Create and Edit Category -->
    <div class="modal fade" id="categoryModal" tabindex="-1" role="dialog" aria-labelledby="categoryModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form id="categoryForm" action="<?php echo e(route('admin.categories.store')); ?>" method="POST"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('POST'); ?> <!-- Default untuk tambah kategori -->

                    <!-- Hidden field untuk id jika mengedit kategori -->
                    <input type="hidden" name="id" id="category_id">

                    <div class="modal-header">
                        <h5 class="modal-title" id="categoryModalLabel">Add Category</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="category_name">Category Name</label>
                            <input type="text" class="form-control" name="category_name" id="category_name" required>
                        </div>
                        <div class="form-group">
                            <label for="description">Description</label>
                            <textarea class="form-control" name="description" id="description"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="image">Category Image</label>
                            <input type="file" class="form-control" name="image" id="image">
                        </div>
                        <div id="image-preview"></div> <!-- Preview image if editing -->
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save Category</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $('#categoryModal').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget); // Button yang men-trigger modal
            var id = button.data('id');
            var name = button.data('category_name');
            var description = button.data('description');
            var image = button.data('image');

            var modal = $(this);
            modal.find('.modal-title').text(id ? 'Edit Category' : 'Add Category');
            modal.find('#category_id').val(id); // Set ID untuk Edit
            modal.find('#category_name').val(name);
            modal.find('#description').val(description);

            // Cek jika ada gambar
            if (image) {
                modal.find('#image-preview').html('<img src="/storage/' + image +
                    '" alt="Category Image" width="100">');
            } else {
                modal.find('#image-preview').html('');
            }

            // Ubah form action untuk Edit atau Add
            if (id) {
                modal.find('form').attr('action', '/admin/categories/' + id); // URL untuk update
                modal.find('form').append('<?php echo method_field('PUT'); ?>'); // Method spoofing untuk PUT (Edit)
            } else {
                modal.find('form').attr('action', '<?php echo e(route('admin.categories.store')); ?>'); // URL untuk store
                modal.find('form').find('input[name="_method"]').remove(); // Hapus method spoofing jika tambah
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TUGAS PRAKTIK\flexora\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>